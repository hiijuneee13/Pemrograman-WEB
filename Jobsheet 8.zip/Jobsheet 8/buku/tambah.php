<?php
session_start();
require_once __DIR__ . '/../koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $judul    = $_POST['judul'] ?? '';
    $penulis  = $_POST['pengarang'] ?? '';
    $tahun    = $_POST['tahun'] ?? null;
    $isbn     = $_POST['isbn'] ?? '';
    $stok     = $_POST['stok'] ?? 0;
    $kategori = $_POST['kategori'] ?? '';

    if (empty($judul) || empty($penulis)) {
        $_SESSION['flash'] = [
            'type'  => 'error',
            'pesan' => 'Judul dan Penulis wajib diisi!'
        ];
        header('Location: tambah.php');
        exit;
    }

    try {
        $sql = "INSERT INTO buku (judul, penulis, tahun_terbit, isbn, stok, kategori) 
                VALUES (:judul, :penulis, :tahun_terbit, :isbn, :stok, :kategori)";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':judul'        => $judul,
            ':penulis'      => $penulis,
            ':tahun_terbit' => $tahun,
            ':isbn'         => $isbn,
            ':stok'         => $stok,
            ':kategori'     => $kategori
        ]);

        $_SESSION['flash'] = [
            'type'  => 'success',
            'pesan' => 'Buku berhasil ditambahkan!'
        ];
        header('Location: list.php');
        exit;
    } catch (PDOException $e) {
        $_SESSION['flash'] = [
            'type'  => 'error',
            'pesan' => 'Gagal menambah buku: ' . $e->getMessage()
        ];
        header('Location: tambah.php');
        exit;
    }
}