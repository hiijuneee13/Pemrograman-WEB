<?php
$page_title = "Daftar Buku";
include __DIR__ . "/../includes/header.php";
require __DIR__ . "/../includes/koneksi.php";

$flash = $_SESSION["flash"] ?? null;
unset($_SESSION["flash"]);

// Latihan 3: pencarian di sisi server. Kata kunci dikirim lewat method GET (?q=...),
// lalu dipakai di query WHERE judul ILIKE :keyword (ILIKE = LIKE tanpa peduli huruf besar/kecil).
$keyword = trim($_GET["q"] ?? "");

if ($keyword !== "") {
    // Karakter % _ \ milik pengguna di-escape supaya dibaca sebagai teks biasa, bukan wildcard.
    $pola = "%" . addcslashes($keyword, "%_\\") . "%";
    $stmt = $pdo->prepare("SELECT * FROM buku WHERE judul ILIKE :keyword ORDER BY id DESC");
    $stmt->execute(["keyword" => $pola]);
    $daftarBuku = $stmt->fetchAll(PDO::FETCH_ASSOC);
} else {
    // Tidak ada nilai dari luar, jadi query() sudah cukup (tidak perlu prepare()).
    $daftarBuku = $pdo->query("SELECT * FROM buku ORDER BY id_buku DESC")->fetchAll(PDO::FETCH_ASSOC);
}
?>
        <section>
            <h2>Daftar Buku</h2>

            <?php if ($flash): ?>
            <div class="flash flash-<?php echo $flash["type"]; ?>">
                <?php echo htmlspecialchars($flash["pesan"]); ?>
            </div>
            <?php endif; ?>

            <div class="search-box">
                <form method="get" action="list.php">
                    <input type="text" id="search-input" name="q" placeholder="Cari judul buku..."
                           value="<?php echo htmlspecialchars($keyword); ?>">
                    <button type="submit">Cari</button>
                    <?php if ($keyword !== ""): ?>
                    <a href="list.php" class="btn-reset">Reset</a>
                    <?php endif; ?>
                </form>
            </div>

            <?php if ($keyword !== ""): ?>
            <p class="info-hasil">
                Ditemukan <?php echo count($daftarBuku); ?> buku untuk kata kunci
                "<?php echo htmlspecialchars($keyword); ?>".
            </p>
            <?php endif; ?>

            <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>Judul</th>
                        <th>Pengarang</th>
                        <th>Tahun</th>
                        <th>Stok</th>
                        <th>Ditambahkan</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($daftarBuku)): ?>
                    <tr>
                        <td colspan="6">
                            <?php echo $keyword !== ""
                                ? "Tidak ada buku yang cocok dengan kata kunci tersebut."
                                : "Belum ada data. Tambahkan lewat menu \"Tambah Buku\"."; ?>
                        </td>
                    </tr>
                    <?php endif; ?>
                    <?php foreach ($daftarBuku as $buku): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($buku["judul"]); ?></td>
                        <td><?= htmlspecialchars($buku['penulis']) ?></td>
                        <td><?= htmlspecialchars($buku['tahun_terbit']) ?></td>
                        <td><?php echo htmlspecialchars($buku["stok"]); ?></td>
                        <td>
                            <?php
                            // Latihan 2: kolom tanggal_ditambahkan (dibuat lewat sql/02_...).
                            $tgl = $buku["tanggal_ditambahkan"] ?? null;
                            echo $tgl ? htmlspecialchars(date("d-m-Y H:i", strtotime($tgl))) : "-";
                            ?>
                        </td>
                        <td>
                            <button type="button">Edit</button>
                            <button type="button" class="btn-detail">Detail</button>
                            <button type="button" class="btn-hapus">Hapus</button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            </div>
        </section>
<?php include __DIR__ . "/../includes/footer.php"; ?>
