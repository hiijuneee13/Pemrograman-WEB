<?php
session_start();
require __DIR__ . "/../includes/koneksi.php";

$judul     = trim($_POST["judul"] ?? "");
$pengarang = trim($_POST["pengarang"] ?? "");
$tahun     = $_POST["tahun"] ?? "";
$isbn      = trim($_POST["isbn"] ?? "");
$stok      = $_POST["stok"] ?? "";
$kategori  = trim($_POST["kategori"] ?? "");
// $tahun dan $stok sengaja tidak di-trim(), keduanya diperiksa sebagai angka.

// ----- Validasi di server (tidak berubah dari jobsheet-07) -----
$errors = [];

if ($judul === "") {
    $errors[] = "Judul wajib diisi.";
}
if ($pengarang === "") {
    $errors[] = "Pengarang wajib diisi.";
}
if (!is_numeric($tahun) || $tahun < 1900 || $tahun > 2026) {
    $errors[] = "Tahun harus di antara 1900-2026.";
}
if (!is_numeric($stok) || $stok < 0) {
    $errors[] = "Stok harus berupa angka, minimal 0.";
}

// Tugas mandiri (slide): validasi format ISBN memakai regex. ISBN boleh kosong,
// tetapi kalau diisi hanya boleh angka dan tanda hubung, dengan 10 atau 13 digit.
if ($isbn !== "") {
    $jumlahDigit = strlen(str_replace("-", "", $isbn));
    if (!preg_match('/^[0-9\-]+$/', $isbn) || !in_array($jumlahDigit, [10, 13], true)) {
        $errors[] = "ISBN hanya boleh berisi angka dan tanda hubung, sebanyak 10 atau 13 digit.";
    }
}

if (!empty($errors)) {
    $_SESSION["flash"] = ["type" => "error", "pesan" => implode(" ", $errors)];
    header("Location: tambah.php");
    exit;
}

// ----- Jobsheet 8: simpan ke PostgreSQL lewat prepared statement -----
// Placeholder (:judul, dst.) diisi saat execute(), nilainya selalu diperlakukan
// sebagai data murni sehingga tidak bisa mengubah struktur query (SQL injection).
$stmt = $pdo->prepare(
    "INSERT INTO buku (judul, pengarang, tahun, isbn, stok, kategori)
     VALUES (:judul, :pengarang, :tahun, :isbn, :stok, :kategori)
     RETURNING id"
);
$stmt->execute([
    "judul"     => $judul,
    "pengarang" => $pengarang,
    "tahun"     => (int) $tahun,
    "isbn"      => $isbn === "" ? null : $isbn,
    "stok"      => (int) $stok,
    "kategori"  => $kategori,
]);

$_SESSION["flash"] = ["type" => "success", "pesan" => "Buku berhasil ditambahkan."];
header("Location: list.php");
exit;
